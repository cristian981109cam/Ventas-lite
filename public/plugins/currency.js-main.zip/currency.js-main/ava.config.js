export default {
  require: ['@babel/register']
};
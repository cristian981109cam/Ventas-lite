## Installation

With [npm](https://www.npmjs.com/):

```sh
npm install --save currency.js
```

With [yarn](https://yarnpkg.com):

```sh
yarn add currency.js
```
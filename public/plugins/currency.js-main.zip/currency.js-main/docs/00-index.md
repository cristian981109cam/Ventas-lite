<header>
  <img src="https://user-images.githubusercontent.com/1062039/31397824-9dfa15f0-adac-11e7-9869-fb20746e90c1.png" alt="currency logo">
  <h1>currency.js</h1>
  <p>{{description}}</p>
  <a class="btn" href="https://unpkg.com/currency.js/{{dist}}">Download currency.js</a>
  <p><strong>v{{version}}</strong> <em>({{size}})</em></p>
  <div class="center">
    <a class="github-button" href="https://github.com/scurker/currency.js" data-icon="octicon-star" data-size="large" data-show-count="true" aria-label="Star scurker/currency.js on GitHub">Star</a>
  </div>
</header>

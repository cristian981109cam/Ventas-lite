## Addons

### [babel-plugin-transform-currency-operators](https://github.com/scurker/babel-plugin-transform-currency-operators)

An experimental babel plugin for transforming currency operators: `currency(1.23) + 4.56` to `currency(1.23).add(4.56)`.
